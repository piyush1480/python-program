import math
n=int(input("Enter a number "))
a=print(math.sqrt(n))