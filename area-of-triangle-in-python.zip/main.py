b=int(input("Enter the base "))
h=int(input("Enter the height "))
area=print((1/2)*b*h)