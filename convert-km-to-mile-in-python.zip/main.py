n=int(input("Enter the distance in km "))
mile=0.625*n
print("Distance in mile is  ",mile)