a=int(input("Enter first number "))
b=int(input("Enter second number "))
print("Sum is ",a+b)