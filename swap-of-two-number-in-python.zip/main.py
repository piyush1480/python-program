a=int(input("Enter the first number "))
b=int(input("Enter the secod number "))
print("Number before swap ", a ,b)
a,b=b,a 
print("Number after swap" ,a ,b)